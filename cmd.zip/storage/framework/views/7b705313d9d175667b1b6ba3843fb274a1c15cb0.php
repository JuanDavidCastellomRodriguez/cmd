<?php $__env->startSection('estilos'); ?>
    <link rel="stylesheet" href="../css/estilos.css">
<?php $__env->stopSection(); ?>

<table align="center" width="90%">
    <tr>
        <td><img height="100" src="<?php echo e(asset('img/logouniminuto.png')); ?>"></td>
        <td><h3 align="center">CORPORACIÓN EL MINUTO DE DIOS<br>LEVANTAMIENTO DE INFORMACIÓN PROGRAMA DE MEJORAMIENTO DE VIVIENDA</h3></td>
        <td><img height="90" src="<?php echo e(asset('img/geopark.png')); ?>"></td>
    </tr>
</table>
<br>
<table align="center" width="90%">
    <tr>
        <td><strong>Municipio: </strong><?php echo e(@$info_vivienda->Predio->Vereda->Municipio->municipio); ?></td>
        <td><strong>Vereda: </strong><?php echo e(@$info_vivienda->Predio->Vereda->vereda); ?></td>
        <td><strong>Nombre del predio: </strong><?php echo e(@$info_vivienda->Predio->nombre_predio); ?></td>
    </tr>
    <tr>
        <td colspan="3"><strong>Fecha: </strong><?php echo e(@$info_vivienda->fecha_encuesta); ?></td>
    </tr>
</table>
<br>
<h3 align="center">PERSONAS QUE HABITAN LA VIVIENDA</h3>
<table align="center" width="90%">
    <tr>
        <td><strong>Nombre de quienes habitan la vivienda</strong></td>
        <td><strong>Edad</strong></td>
        <td><strong>Cédula</strong></td>
        <td><strong>No. telefónico</strong></td>
        <td><strong>Estado civil</strong></td>
        <td><strong>Nivel educativo</strong></td>
        <td><strong>Ocupación</strong></td>
    </tr>
    <?php $__currentLoopData = @$info_vivienda->HabitantesViviendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitante): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><?php echo e(@$habitante->nombres); ?> <?php echo e(@$habitante->apellidos); ?></td>
            <td><?php echo e(@$habitante->fecha_nacimiento); ?></td>
            <td><?php echo e(@$habitante->no_cedula); ?></td>
            <td><?php echo e(@$habitante->no_celular); ?></td>
            <td><?php echo e(@$habitante->Estados_civil->estado_civil); ?></td>
            <td><?php echo e(@$habitante->Nivel_educativo->nivel_educativo); ?></td>
            <td><?php echo e(@$habitante->ocupacion); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<br>
<h3 align="center">PERSONAS A CARGO</h3>
<table align="center" width="90%">
    <tr>
        <td><strong>Edad</strong></td>
        <td><strong>Género</strong></td>
        <td><strong>Nivel educativo</strong></td>
        <td><strong>Tipo</strong></td>
        <td><strong>Observaciones</strong></td>
    </tr>
    <?php $__currentLoopData = @$info_vivienda->PersonasCargo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personascargo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><?php echo e(@$personascargo->fecha_nacimiento); ?></td>
            <td><?php echo e(@$personascargo->Genero->genero); ?></td>
            <td><?php echo e(@$personascargo->Nivel_educativo->nivel_educativo); ?></td>
            <td><?php echo e(@$personascargo->Tipo_personas_cargo->tipo_persona); ?></td>
            <td><?php echo e(@$personascargo->observaciones); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<br>
<h3 align="center">Fotografías</h3>
<center>
    <?php $__currentLoopData = @$info_vivienda->Fotografias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <img width="30%" src="<?php echo e(asset(@$fotografia->ruta)); ?>">

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</center>
