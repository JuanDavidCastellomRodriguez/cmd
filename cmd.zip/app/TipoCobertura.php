<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoCobertura extends Model
{
    //
}
