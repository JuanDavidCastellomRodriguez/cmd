<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstadosVia extends Model
{
    //
}
