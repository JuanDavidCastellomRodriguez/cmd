<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cocina extends Model
{
    //
}
