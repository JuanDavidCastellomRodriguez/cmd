<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EtapasCultivo extends Model
{
    //
}
