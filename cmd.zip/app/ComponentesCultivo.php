<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ComponentesCultivo extends Model
{
    //
}
