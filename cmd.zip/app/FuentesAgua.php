<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FuentesAgua extends Model
{
    //
}
