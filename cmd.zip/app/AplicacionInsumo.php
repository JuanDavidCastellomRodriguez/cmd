<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AplicacionInsumo extends Model
{
    //
}
