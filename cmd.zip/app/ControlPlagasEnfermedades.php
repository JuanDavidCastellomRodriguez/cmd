<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ControlPlagasEnfermedades extends Model
{
    //
}
