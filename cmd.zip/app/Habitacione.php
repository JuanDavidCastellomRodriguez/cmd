<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Habitacione extends Model
{
    //
}
