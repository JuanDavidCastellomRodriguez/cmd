<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoTenenciaTierra extends Model
{
    //
}
