<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaterialesTanquesElevado extends Model
{
    //
}
