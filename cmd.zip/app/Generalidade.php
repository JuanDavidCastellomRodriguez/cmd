<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Generalidade extends Model
{
    //
}
