<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaterialesTanquesLavadero extends Model
{
    //
}
