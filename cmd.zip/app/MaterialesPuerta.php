<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaterialesPuerta extends Model
{
    //
}
