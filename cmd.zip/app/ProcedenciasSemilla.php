<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProcedenciasSemilla extends Model
{
    //
}
