<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SitioVenta extends Model
{
    //
}
