<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PropietariosPredio extends Model
{
    //
}
