<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FrecuenciaOrdenio extends Model
{
    //
}
